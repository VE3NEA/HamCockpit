This zip file contains additional plugins for Ham Cockpit. 

After downloading the zip, right-click on it, click on Properties, 
tick the Unblock checkbox, and click on OK.

Once the zip is unblocked, extract all files to the folder where HamCockpit.exe 
is installed.

Included plugins:
  - Clock Demo
  - Conventional Radio
  - Frequency Display
  - Plugin List panel
  - S-Meter
  
For more information visit https://ve3nea.github.io/hamcockpit  
