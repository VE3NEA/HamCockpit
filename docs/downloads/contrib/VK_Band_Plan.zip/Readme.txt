This zip file includes the Australian band plan for the Ham Cockpit software.

The band plan was created by Graham Alston <graham@alston.com.au> 
based on the Australian Amateur Band Plans document.

To add the band plan to Ham Cockpit, type this in File Explorer:

%programdata%\Afreet\HamCockpit\VE3NEA\BandPlans

This will open the folder in which the band plan files are stored.
Unzip the "VK Band Plan.json" file in that folder.

Now if you click on the Band Plan button on the HamCockpit toolbar, you will 
see the new band plan in the list of available band plans.

Ham Cockpit is available here: https://ve3nea.github.io/HamCockpit/
